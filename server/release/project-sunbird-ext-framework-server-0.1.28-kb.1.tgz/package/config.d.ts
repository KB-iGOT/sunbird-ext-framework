/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import { FrameworkConfig } from './interfaces';
export declare const defaultConfig: FrameworkConfig;
