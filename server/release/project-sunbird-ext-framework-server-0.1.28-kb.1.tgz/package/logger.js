Object.defineProperty(exports, "__esModule", { value: true });
const log4js_1 = require("log4js");
const path = require("path");
const fs = require("fs");
const logger = log4js_1.getLogger();
exports.logger = logger;
logger.level = 'off';
const configureLogger = (basePath) => {
    log4js_1.configure({
        "appenders": {
            "access": {
                "type": "dateFile",
                "filename": path.join(basePath, "log", "access.log"),
                "pattern": "-yyyy-MM-dd",
                "category": "http",
                "maxLogSize": 10485760,
                "backups": 3,
                "compress": true
            },
            "app": {
                "type": "file",
                "filename": path.join(basePath, "log", "app.log"),
                "maxLogSize": 10485760,
                "backups": 3,
                "compress": true
            },
            "errorFile": {
                "type": "file",
                "filename": path.join(basePath, "log", "errors.log"),
                "maxLogSize": 10485760,
                "backups": 3,
                "compress": true
            },
            "errors": {
                "type": "logLevelFilter",
                "level": "ERROR",
                "appender": "errorFile"
            },
            "console": {
                "type": "console",
                "layout": {
                    "type": "coloured"
                }
            }
        },
        "categories": {
            "default": { "appenders": ["app", "errors", "console"], "level": "DEBUG" },
            "http": { "appenders": ["access"], "level": "DEBUG" }
        }
    });
};
function enableLogger(config) {
    let basePath = config.logBasePath || __dirname;
    try {
        if (!fs.existsSync(path.join(basePath, 'log'))) {
            fs.mkdirSync(path.join(basePath, 'log'));
        }
    }
    catch (error) {
        console.error(`error while creating log folder while enabling logger ${error}`);
    }
    configureLogger(basePath);
    logger.level = config.logLevel || 'debug';
}
exports.enableLogger = enableLogger;
//# sourceMappingURL=logger.js.map