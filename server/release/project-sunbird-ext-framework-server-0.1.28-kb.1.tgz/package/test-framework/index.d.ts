import { FrameworkConfig } from '../interfaces';
export declare class TestFramework {
    private static config;
    static initialize(config: FrameworkConfig): Promise<void>;
}
