export declare class Util {
    static hash(text: string): string;
    static generateId(prefix: string, id: string): string;
    static UUID(): any;
}
export declare enum FrameworkErrors {
    MANIFEST_NOT_FOUND = 0,
    MANIFEST_NOT_PARSEABLE = 1,
    ENTRY_FILE_NOT_FOUND = 2,
    METHOD_NOT_IMPLEMENTED = 3,
    PLUGIN_LOAD_FAILED = 4,
    PLUGIN_BUILD_FAILED = 5,
    PLUGIN_INSTANCE_FAILED = 6,
    ROUTE_REGISTRY_FAILED = 7,
    ROUTER_FILE_NOT_FOUND = 8,
    PLUGIN_ROUTE_INIT_FAILED = 9,
    UNKNOWN_ERROR = 10,
    DB_ERROR = 11,
    SCHEMA_LOADER_FAILED = 12,
    INVALID_SCHEMA_PATH = 13,
    PLUGIN_REGISTERED = 14,
    PLUGIN_REGISTER_FAILED = 15,
    INVALID_AUTH_PROVIDER = 16,
    AUTH_PROVIDER_ALREADY_CONFIGURED = 17
}
export interface ErrorSubclass extends Error {
}
export declare class ErrorSubclass {
    name: string;
    message: string;
    stack: string;
    constructor(message: string);
}
export interface FrameworkErrorOptions {
    message?: string;
    detail?: string;
    extendedInfo?: string;
    code: FrameworkErrors;
    rootError?: any;
}
export declare class FrameworkError extends ErrorSubclass {
    name: string;
    detail: string;
    extendedInfo: string;
    code: FrameworkErrors;
    rootError: any;
    constructor(options: FrameworkErrorOptions);
    print(): string;
}
export declare function delayPromise(duration: any): (...args: any[]) => Promise<{}>;
