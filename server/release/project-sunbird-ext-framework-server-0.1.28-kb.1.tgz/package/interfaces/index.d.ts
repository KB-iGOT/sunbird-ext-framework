import { Router } from 'express';
import { Manifest } from '../models/Manifest';
import { ConfigOptions, Client as ESClient } from 'elasticsearch';
import { loggerLevels } from '../logger';
import { ITelemetry } from '../services/telemetry/interfaces/TelemetryService';
export interface IRouter {
    init(app: Router, auth: any, manifest: Manifest): void;
}
export interface IRouterConstructor {
    new (): IRouter;
}
export interface IServer {
}
export interface IServerConstructor {
    new (manifest: Manifest): IServer;
}
export interface IElasticSearchConfig extends ConfigOptions {
    host: string;
    disabledApis: Array<string>;
}
export interface IPlugin {
    id: string;
    ver: string;
}
export interface ICassandraConfig {
    defaultKeyspaceSettings?: {
        replication: {
            class: string;
            replication_factor: string;
        };
        udts?: Object;
    };
    contactPoints: Array<string>;
    keyspace?: string;
    localDataCenter?: string;
    port?: number;
    queryOptions?: QueryOptions;
}
export interface QueryOptions {
    consistency: number;
}
export interface ICassandraConnector {
}
export interface IElasticSearchConnector extends ESClient {
}
export interface IDatabaseConfig {
    cassandra: ICassandraConfig;
    elasticsearch: IElasticSearchConfig;
    couchdb: ICouchDBConfig;
    pouchdb: IPouchDBConfig;
}
export interface FrameworkConfig {
    db?: IDatabaseConfig;
    plugins: Array<IPlugin>;
    pluginBasePath: string;
    secureContextParams?: Array<string>;
    port?: number;
    telemetry?: ITelemetry;
    logLevel?: loggerLevels;
    logBasePath?: string;
}
export declare enum PluginStatusEnum {
    unknown = 0,
    created = 1,
    registered = 2,
    installed = 3,
    resolved = 4,
    started = 5,
    stopped = 6,
    active = 7,
    uninstalled = 8,
    unregistered = 9
}
export interface PluginMeta {
    id?: string;
    name?: string;
    version?: string;
    repo?: string;
    registered_on?: Date;
    cassandra_keyspace?: string;
    elasticsearch_index?: any;
    database_name?: string;
    status?: PluginStatusEnum;
    manifest?: string;
}
export interface IMetaDataProvider {
    getMeta(id: string): any;
    updateMeta(id: string, meta: PluginMeta): any;
    createMeta(meta: PluginMeta): any;
    deleteMeta(id: string): any;
}
/**
 * Interface for Message providers
 *
 * @export
 * @interface IMessageProvider
 */
export interface IMessageProvider {
    /**
     * Initialize the provider with config details
     *
     * @param {object} config
     * @memberof IMessageProvider
     */
    initialize(config: object): any;
    /**
     *
     * To register event producer.
     * @param {string} id format: <pluginId>
     * @param {object} [options]
     * @memberof IMessageProvider
     */
    registerProducer(id: string, options?: object): any;
    /**
     *
     * To unregister producer. Producer cannot publish message or create topic after unregisteration
     * @param {string} id
     * @memberof IMessageProvider
     */
    unregisterProducer(id: string): any;
    /**
     *
     * To publish message to all consumers
     * @param {string} topic
     * @param {object} payload
     * @memberof IMessageProvider
     */
    publishMessage(topic: string, payload: object): any;
    /**
     *
     * To register consumer based on topic created by producer
     * @param {string} topic
     * @param {object} [options]
     * @memberof IMessageProvider
     */
    registerConsumer(topic: string, options?: object): any;
    /**
     *
     * To unregsiter consumer. Consumer cannot reveice any message after unregistration
     * @param {string} id
     * @memberof IMessageProvider
     */
    unregisterConsumer(id: string): any;
    /**
     *
     * To create topic. Only producer can create topics
     * @param {Array<string>} names format: <pluginId>:<actionPrefix>_<eventName>_<version>
     * e.g: ["org.sunbird.profile:post_createDocument_v1"]
     * @memberof IMessageProvider
     */
    createTopic(names: Array<string>): any;
}
export interface ICouchDBConfig {
    url: string;
}
export interface IPouchDBConfig {
    path: string;
    adaptor?: string;
}
