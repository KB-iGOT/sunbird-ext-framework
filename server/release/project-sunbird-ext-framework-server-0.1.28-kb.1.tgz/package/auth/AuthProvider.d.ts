import { IAuthProvider, IAuthProviderConstructor } from './IAuthProvider';
export declare class AuthProvider {
    private providers;
    private providerInUse;
    register(provider: IAuthProviderConstructor): void;
    unregister(provider: IAuthProviderConstructor): void;
    getDefault(): IAuthProvider;
    use(provider: IAuthProvider): void;
}
export declare const authProvider: AuthProvider;
