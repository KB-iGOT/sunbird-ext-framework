Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IAuthProvider.js.map