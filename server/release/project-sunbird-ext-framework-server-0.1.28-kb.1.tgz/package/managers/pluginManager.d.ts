/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import { IPlugin, FrameworkConfig } from '../interfaces';
import { PluginLoader } from './PluginLoader';
export declare class PluginManager {
    pluginLoader: PluginLoader;
    private _config;
    initialize(config: FrameworkConfig): void;
    load(config: FrameworkConfig): Promise<void>;
    getPluginInstance(pluginId: string): any;
    loadPlugin(plugin: IPlugin): Promise<void>;
}
