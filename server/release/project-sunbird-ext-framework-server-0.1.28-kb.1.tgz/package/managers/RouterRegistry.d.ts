/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import * as express from 'express';
import { Manifest } from '../models/Manifest';
export declare class RouterRegistry {
    private rootApp;
    private routerInstances;
    private threadLocalNamespace;
    initialize(app: express.Express): void;
    /**
     *
     *
     * @param {Manifest} manifest
     * @returns {Router}
     * @memberof RouterRegistry
     */
    bindRouter(manifest: Manifest): express.Router;
    getThreadNamespace(): any;
    threadLocal(namespace: any): express.RequestHandler;
    registerStaticRoute(filePath: string, prefix?: string): void;
    setStaticViewEngine(name: string): void;
}
