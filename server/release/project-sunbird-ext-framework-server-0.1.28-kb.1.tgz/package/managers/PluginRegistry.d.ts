/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import { Manifest } from "../models/Manifest";
import { PluginStatusEnum } from "../interfaces";
import { InMemoryMetaDataProvider } from "../meta/InMemoryMetaDataProvider";
/**
 *
 *
 * @export
 * @class PluginRegistry
 */
export declare class PluginRegistry {
    metaDataProvider: InMemoryMetaDataProvider;
    private config;
    initialize(config: {
        metaProviderConfig: any;
    }): void;
    /**
     *
     *
     * @static
     * @param {Manifest} manifest
     * @returns {Promise<void>}
     * @memberof PluginRegistry
     */
    register(manifest: Manifest): Promise<Boolean>;
    /**
     *
     *
     * @static
     * @param {string} id
     * @returns
     * @memberof PluginRegistry
     */
    unregister(id: string): Promise<void>;
    /**
     *
     *
     * @static
     * @param {string} id
     * @returns {Promise<boolean>}
     * @memberof PluginRegistry
     */
    isRegistered(id: string): Promise<boolean>;
    /**
     *
     *
     * @static
     * @param {string} id
     * @returns {Promise<PluginStatusEnum | undefined>}
     * @memberof PluginRegistry
     */
    getStatus(id: string): Promise<PluginStatusEnum | undefined>;
    /**
     *
     *
     * @static
     * @param {string} id
     * @param {PluginStatusEnum} status
     * @returns
     * @memberof PluginRegistry
     */
    updateStatus(id: string, status: PluginStatusEnum): Promise<any>;
}
