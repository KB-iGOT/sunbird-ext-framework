/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import { Manifest } from '../models/Manifest';
import { IPlugin, FrameworkConfig } from '../interfaces';
import { PluginRegistry } from './PluginRegistry';
import { RouterRegistry } from './RouterRegistry';
import { SchemaLoader } from '../db';
export declare class PluginLoader {
    pluginRegistry: PluginRegistry;
    routerRegistry: RouterRegistry;
    schemaLoader: SchemaLoader;
    private config;
    private pluginsLoaded;
    private pluginInstances;
    initialize(config: FrameworkConfig): void;
    loadDBSchema(manifest: Manifest, path: string): Promise<void>;
    getPluginManifest(pluginId: string): Manifest;
    getPluginInstance(pluginId: string): any;
    loadDependencies(manifest: Manifest): Promise<void>;
    /**
     * Steps:
     *  1) Put a placeholder to indicate that this plugin is triggered for load so the cyclic dependencies don't kill the process
     *  2) Load manifest
     *  3) Load dependencies first
     *  4) Register the plugin
     *  5) Prepare the plugin - create/alter schema, run migration
     *  6) Instantiate the plugin
     *  7) Register the routes
     *
     * @param plugin IPlugin
     */
    loadPlugin(plugin: IPlugin): Promise<void>;
    buildPlugin(manifest: any): Promise<void>;
    isPluginLoaded(pluginId: string): boolean;
    private register;
    private unregister;
    private getManifest;
    private preparePlugin;
    private instantiatePlugin;
    private registerRoutes;
}
