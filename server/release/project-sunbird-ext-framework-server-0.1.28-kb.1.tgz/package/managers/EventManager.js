Object.defineProperty(exports, "__esModule", { value: true });
const mitt = require("mitt");
class EventManager {
    static emit(name, data) {
        this.emitter.emit(name, data);
    }
    static subscribe(name, method) {
        this.emitter.on(name, method);
    }
    static unsubscribe(name, method) {
        this.emitter.off(name, method);
    }
}
EventManager.emitter = new mitt();
exports.EventManager = EventManager;
//# sourceMappingURL=EventManager.js.map