import * as mitt from 'mitt';
export declare class EventManager {
    static emitter: mitt.Emitter;
    static emit(name: string, data: any): void;
    static subscribe(name: string, method: any): void;
    static unsubscribe(name: string, method: any): void;
}
