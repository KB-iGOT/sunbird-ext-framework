/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import { SchemaLoader } from './db';
import { Express } from 'express';
import { RouterRegistry } from './managers/RouterRegistry';
import { PluginManager } from './managers/pluginManager';
import { FrameworkConfig } from './interfaces';
import { TelemetryService } from './services/telemetry';
export declare class Framework {
    routerRegistry: RouterRegistry;
    pluginManager: PluginManager;
    telemetryService: TelemetryService;
    schemaLoader: SchemaLoader;
    initialized: boolean;
    private _config;
    readonly config: FrameworkConfig;
    initialize(config: FrameworkConfig, app: Express): Promise<void>;
    loadPluginRegistrySchema(): Promise<void>;
}
export * from './api';
export * from './interfaces';
export * from './models';
export * from './services';
export * from './util';
