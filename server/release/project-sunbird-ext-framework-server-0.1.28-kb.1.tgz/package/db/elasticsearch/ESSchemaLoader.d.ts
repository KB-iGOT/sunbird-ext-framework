/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import { IElasticSearchConfig } from '../../interfaces';
import { ISchemaLoader } from '..';
export declare class ESSchemaLoader implements ISchemaLoader {
    private _config;
    private dbConnection;
    private metaDataProvider;
    private elasticSearchDB;
    constructor(config: IElasticSearchConfig);
    alter(pluginId: string, schemaData: object): Promise<void>;
    migrate(pluginId: string, schemaData: object): Promise<void>;
    getType(): string;
    exists(pluginId: string, schema: any): Promise<void>;
    create(pluginId: string, schema: any): Promise<void>;
    private validateSchema;
    private createIndex;
    private generateESIndexAlias;
    private isIndexDefined;
    private createSchema;
    private createIndexAlias;
}
