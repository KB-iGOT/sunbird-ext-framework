/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import { IElasticSearchConfig, IElasticSearchConnector } from "../../interfaces";
export declare class ElasticSearchDB {
    private _config;
    initialize(config: IElasticSearchConfig): void;
    getConnection(pluginId: string): IElasticSearchConnector;
    private proxyMethod;
}
