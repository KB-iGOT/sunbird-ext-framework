/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
export interface ISchemaLoader {
    getType(): string;
    exists(pluginId: string, schema: any): any;
    create(pluginId: string, schema: any): any;
    alter(pluginId: string, schema: any): any;
    migrate(pluginId: string, schema: any): any;
}
