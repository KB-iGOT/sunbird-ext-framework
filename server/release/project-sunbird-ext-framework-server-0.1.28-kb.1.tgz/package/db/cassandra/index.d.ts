/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import { ICassandraConfig } from "../../interfaces";
export declare class CassandraDB {
    private _config;
    private schemaService;
    private cassandraConnection;
    initialize(config: ICassandraConfig): void;
    closeCassandraConnections(): Promise<{}>;
    getConnectionByKeyspace(keyspace?: string, defaultSettings?: ICassandraConfig["defaultKeyspaceSettings"]): Promise<any>;
    getConnectionByPlugin(pluginId: string): any;
    getConnection(keyspace: string, defaultSettings?: ICassandraConfig["defaultKeyspaceSettings"]): any;
}
