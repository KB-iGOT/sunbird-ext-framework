/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import { ISchemaLoader } from '../ISchemaLoader';
import { ICassandraConfig } from '../../interfaces';
export declare class CassandraSchemaLoader implements ISchemaLoader {
    private _config;
    private dbConnection;
    private metaDataProvider;
    private schemaService;
    private cassandraDB;
    constructor(config: ICassandraConfig);
    getType(): string;
    exists(pluginId: string, schema: object): Promise<void>;
    alter(pluginId: string, schema: object): Promise<void>;
    migrate(pluginId: string, schema: object): Promise<void>;
    create(pluginId: string, schema: any): Promise<void>;
    private validateSchema;
}
