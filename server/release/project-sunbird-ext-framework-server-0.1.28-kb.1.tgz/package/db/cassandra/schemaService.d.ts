export declare class SchemaService {
    private schemaMap;
    setSchema(pluginId: string, schema: any): void;
    getSchemaByPlugin(pluginId: string): any;
    getSchemaBykeyspace(keyspace: string): {};
}
