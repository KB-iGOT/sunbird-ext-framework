/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import { ISchemaLoader } from './ISchemaLoader';
export declare class SchemaLoader {
    private loaders;
    registerLoader(loader: ISchemaLoader): void;
    getLoader(type: string): ISchemaLoader;
}
