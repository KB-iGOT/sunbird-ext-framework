/**
 * @author Harish Kumar Gangula <harishg@ilimi.in>
 */
import { ICouchDBConfig } from "../../interfaces";
export declare class CouchDB {
    private _config;
    initialize(config: ICouchDBConfig): void;
    getConnection(pluginId: string): any;
    private proxyMethod;
}
