export declare class SchemaService {
    private schemaMap;
    setSchema(pluginId: string, schema: any): void;
    getSchemaByPlugin(pluginId: string): any;
    getSchemaByDatabase(database: string): any;
}
