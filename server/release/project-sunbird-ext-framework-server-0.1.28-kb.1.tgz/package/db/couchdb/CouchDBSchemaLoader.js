/**
 * @author Harish Kumar Gangula <harishg@ilimi.in>
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const util_1 = require("../../util");
const _ = require("lodash");
const schemaService_1 = require("./schemaService");
const logger_1 = require("../../logger");
const typescript_ioc_1 = require("typescript-ioc");
const _1 = require(".");
let CouchDBSchemaLoader = class CouchDBSchemaLoader {
    constructor(config) {
        this._config = config;
        this.couchDB.initialize(config);
    }
    getType() {
        return 'couchdb';
    }
    exists(pluginId, schema) {
        return __awaiter(this, void 0, void 0, function* () {
            // TODO: complete implementation
        });
    }
    alter(pluginId, schema) {
        return __awaiter(this, void 0, void 0, function* () {
            // TODO: complete implementation
        });
    }
    migrate(pluginId, schema) {
        return __awaiter(this, void 0, void 0, function* () {
            // TODO: complete implementation
        });
    }
    create(pluginId, schema) {
        return __awaiter(this, void 0, void 0, function* () {
            logger_1.logger.info('loading schema for plugin: ', pluginId);
            this.dbConnection = this.couchDB.getConnection(pluginId);
            // setSchema
            this.schemaService.setSchema(pluginId, Object.assign({}, schema));
            _.forEach(schema.databases, (db) => {
                const databaseName = util_1.Util.generateId(pluginId, db.name);
                db.database_name = databaseName;
            });
            let dbsList = yield this.dbConnection.db.list();
            // create databases 
            for (const db of schema.databases) {
                if (!_.includes(dbsList, db.database_name)) {
                    yield this.dbConnection.db.create(db.database_name).catch((err) => {
                        if (err)
                            throw new util_1.FrameworkError({ message: `"${pluginId}" : unable to create database ${db.name} `, code: util_1.FrameworkErrors.DB_ERROR });
                    });
                }
                else {
                    logger_1.logger.warn(`${db.name} database in couchdb is already exists so ignoring`);
                }
            }
            // create views for each database
            for (const db of schema.databases) {
                let dbInstance = this.dbConnection.db.use(db.name);
                if (!_.isEmpty(db['views'])) {
                    for (let view of db.views) {
                        yield dbInstance.insert(view).catch((err) => {
                            if (err)
                                throw new util_1.FrameworkError({ message: `"${pluginId}" : unable to create view ${JSON.stringify(view)} for ${db.name} `, code: util_1.FrameworkErrors.DB_ERROR });
                        });
                    }
                }
            }
            // create indexes for each database
            for (const db of schema.databases) {
                let dbInstance = this.dbConnection.db.use(db.name);
                if (!_.isEmpty(db['indexes'])) {
                    for (let index of db.indexes) {
                        yield dbInstance.createIndex(index).catch((err) => {
                            if (err)
                                throw new util_1.FrameworkError({ message: `"${pluginId}" : unable to create index ${JSON.stringify(index)} for ${db.name} `, code: util_1.FrameworkErrors.DB_ERROR });
                        });
                    }
                }
            }
        });
    }
};
__decorate([
    typescript_ioc_1.Inject,
    __metadata("design:type", schemaService_1.SchemaService)
], CouchDBSchemaLoader.prototype, "schemaService", void 0);
__decorate([
    typescript_ioc_1.Inject,
    __metadata("design:type", _1.CouchDB)
], CouchDBSchemaLoader.prototype, "couchDB", void 0);
CouchDBSchemaLoader = __decorate([
    typescript_ioc_1.Singleton,
    __metadata("design:paramtypes", [Object])
], CouchDBSchemaLoader);
exports.CouchDBSchemaLoader = CouchDBSchemaLoader;
//# sourceMappingURL=CouchDBSchemaLoader.js.map