/**
 * @author Harish Kumar Gangula <harishg@ilimi.in>
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const nano = require("nano");
const util_1 = require("../../util");
const typescript_ioc_1 = require("typescript-ioc");
let CouchDB = class CouchDB {
    initialize(config) {
        this._config = config;
    }
    getConnection(pluginId) {
        const url = this._config.url;
        const connection = nano(url);
        connection.db = this.proxyMethod(connection.db, pluginId);
        return connection;
    }
    proxyMethod(obj, pluginId) {
        let handler = {
            get: function (target, property) {
                switch (property) {
                    case 'use':
                        return function () {
                            let dbName = util_1.Util.generateId(pluginId, arguments[0]);
                            return target[property].apply(target, [dbName]);
                        };
                        break;
                }
                return target[property];
            }
        };
        return new Proxy(obj, handler);
    }
};
CouchDB = __decorate([
    typescript_ioc_1.Singleton
], CouchDB);
exports.CouchDB = CouchDB;
//# sourceMappingURL=index.js.map