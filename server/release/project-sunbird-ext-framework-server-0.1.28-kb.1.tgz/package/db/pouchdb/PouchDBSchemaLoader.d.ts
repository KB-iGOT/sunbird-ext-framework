/**
 * @author Harish Kumar Gangula <harishg@ilimi.in>
 */
import { ISchemaLoader } from '../ISchemaLoader';
import { IPouchDBConfig } from '../../interfaces';
export declare class PouchDBSchemaLoader implements ISchemaLoader {
    private _config;
    private dbConnection;
    private schemaService;
    private pouchDB;
    constructor(config: IPouchDBConfig);
    getType(): string;
    exists(pluginId: string, schema: object): Promise<void>;
    alter(pluginId: string, schema: object): Promise<void>;
    migrate(pluginId: string, schema: object): Promise<void>;
    create(pluginId: string, schema: any): Promise<void>;
}
