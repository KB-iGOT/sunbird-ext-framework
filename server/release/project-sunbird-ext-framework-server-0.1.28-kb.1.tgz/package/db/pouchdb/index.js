/**
 * @author Harish Kumar Gangula <harishg@ilimi.in>
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const PouchDataBase = require('pouchdb');
const util_1 = require("../../util");
const typescript_ioc_1 = require("typescript-ioc");
const path = require("path");
PouchDataBase.plugin(require('pouchdb-find'));
let PouchDB = class PouchDB {
    initialize(config) {
        this._config = config;
    }
    getConnection(pluginId, dbName) {
        const dbPath = this._config.path;
        // TODO: add the proxy method to restrict 
        return new PouchDataBase(path.join(dbPath, util_1.Util.generateId(pluginId, dbName)));
    }
};
PouchDB = __decorate([
    typescript_ioc_1.Singleton
], PouchDB);
exports.PouchDB = PouchDB;
//# sourceMappingURL=index.js.map