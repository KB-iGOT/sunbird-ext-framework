/**
 * @author Harish Kumar Gangula <harishg@ilimi.in>
 */
import { IPouchDBConfig } from "../../interfaces";
export declare class PouchDB {
    private _config;
    initialize(config: IPouchDBConfig): void;
    getConnection(pluginId: string, dbName: string): any;
}
