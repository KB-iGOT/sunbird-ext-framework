import { IMetaDataProvider, PluginMeta } from "../interfaces";
export declare class InMemoryMetaDataProvider implements IMetaDataProvider {
    private store;
    initialize(config?: any): void;
    getMeta(id: string): Promise<any>;
    updateMeta(id: string, meta: PluginMeta): Promise<any>;
    createMeta(meta: PluginMeta): Promise<any>;
    deleteMeta(id: string): Promise<any>;
}
