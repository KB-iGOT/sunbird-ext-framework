export declare const RegistrySchema: {
    "type": string;
    "private": boolean;
    "config": {
        "replication": {
            "class": string;
            "replication_factor": number;
        };
    };
    "keyspace_prefix": string;
    "keyspace_name": string;
    "column_families": {
        "table_name": string;
        "fields": {
            "id": {
                "type": string;
            };
            "name": {
                "type": string;
            };
            "version": {
                "type": string;
            };
            "repo": {
                "type": string;
            };
            "status": {
                "type": string;
            };
            "registered_on": {
                "type": string;
                "default": {
                    "$db_function": string;
                };
            };
            "cassandra_keyspace": {
                "type": string;
            };
            "elasticsearch_index": {
                "type": string;
                "typeDef": string;
            };
            "manifest": {
                "type": string;
            };
        };
        "key": string[];
    }[];
};
