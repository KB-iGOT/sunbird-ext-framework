var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const logger_1 = require("../logger");
const typescript_ioc_1 = require("typescript-ioc");
let InMemoryMetaDataProvider = class InMemoryMetaDataProvider {
    constructor() {
        this.store = {};
    }
    initialize(config) {
        this.store = {};
    }
    getMeta(id) {
        return __awaiter(this, void 0, void 0, function* () {
            yield new Promise((resolve, reject) => {
                this.store[id] ? resolve({ rows: [this.store[id]] }) : reject(`Error while getting meta data for ${id}`);
            }).catch(error => {
                logger_1.logger.error('error when getting meta data', error);
            });
        });
    }
    updateMeta(id, meta) {
        return __awaiter(this, void 0, void 0, function* () {
            yield new Promise((resolve, reject) => {
                let oldData = this.store[id];
                if (oldData) {
                    this.store[id] = Object.assign({}, oldData, meta);
                    resolve(this.store[id]);
                }
                else {
                    reject(`Error while updating meta data for ${id}, it is not created`);
                }
            }).catch(error => {
                logger_1.logger.error('error when updating meta data', error);
            });
        });
    }
    createMeta(meta) {
        return __awaiter(this, void 0, void 0, function* () {
            yield new Promise((resolve, reject) => {
                if (this.store[meta.id]) {
                    reject('Error meta data already exists');
                }
                else {
                    this.store[meta.id] = meta;
                    resolve(meta.id);
                }
            }).catch(error => {
                logger_1.logger.error('error when creating meta data', error);
            });
        });
    }
    deleteMeta(id) {
        return __awaiter(this, void 0, void 0, function* () {
            yield new Promise((resolve, reject) => {
                if (!this.store[id]) {
                    reject('Error meta data not exists');
                }
                else {
                    delete this.store[id];
                    resolve(id);
                }
            }).catch(error => {
                logger_1.logger.error('error when deleting meta data', error);
            });
        });
    }
};
InMemoryMetaDataProvider = __decorate([
    typescript_ioc_1.Singleton
], InMemoryMetaDataProvider);
exports.InMemoryMetaDataProvider = InMemoryMetaDataProvider;
//# sourceMappingURL=InMemoryMetaDataProvider.js.map