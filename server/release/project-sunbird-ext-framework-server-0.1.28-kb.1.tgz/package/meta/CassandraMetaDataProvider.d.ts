import { IMetaDataProvider, PluginMeta, ICassandraConfig } from "../interfaces";
export declare class CassandraMetaDataProvider implements IMetaDataProvider {
    private connection;
    private cassandraDB;
    initialize(config: ICassandraConfig): void;
    getMeta(id: string): Promise<any>;
    updateMeta(id: string, meta: PluginMeta): Promise<any>;
    createMeta(meta: PluginMeta): Promise<any>;
    deleteMeta(id: string): Promise<any>;
    private getConnection;
}
