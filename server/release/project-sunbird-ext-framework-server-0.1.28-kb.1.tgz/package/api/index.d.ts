/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import { FrameworkConfig, IElasticSearchConnector } from "../interfaces";
import { Express } from 'express';
import { TelemetryService } from '../services';
export * from '../services/telemetry/interfaces/TelemetryService';
export * from '../interfaces';
export declare class FrameworkAPI {
    private config;
    private framework;
    private cassandraDB;
    private elasticSearchDB;
    private _telemetryService;
    private couchDB;
    private pouchDB;
    private routerRegistry;
    bootstrap(config: FrameworkConfig, app: Express): Promise<void>;
    closeCassandraConnections(): Promise<{}>;
    getCassandraInstance(pluginId: string): any;
    getElasticsearchInstance(pluginId: string): IElasticSearchConnector;
    telemetryService(): TelemetryService;
    threadLocal(): any;
    getPluginInstance(id: string): any;
    getCouchDBInstance(pluginId: string): any;
    registerStaticRoute(path: string, prefix?: string): void;
    setStaticViewEngine(name: string): void;
    getPouchDBInstance(pluginId: string, dbName: string): any;
}
export declare const frameworkAPI: FrameworkAPI;
