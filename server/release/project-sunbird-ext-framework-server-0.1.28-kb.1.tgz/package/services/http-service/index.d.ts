import { AxiosRequestConfig, AxiosResponse } from 'axios';
import { Observable } from 'rxjs';
export interface IHttpRequestConfig extends AxiosRequestConfig {
}
export interface IHttpResponse extends AxiosResponse {
}
/**
 *
 *
 * @export
 * @class HTTPService
 */
export declare class HTTPService {
    /**
     *
     *
     * @param {string} url
     * @param {IHttpRequestConfig} config
     * @returns {Observable<IHttpResponse>}
     * @memberof HTTPService
     */
    static get(url: string, config: IHttpRequestConfig): Observable<IHttpResponse>;
    /**
     *
     *
     * @param {string} url
     * @param {IHttpRequestConfig} [config]
     * @returns {Observable<IHttpResponse>}
     * @memberof HTTPService
     */
    static delete(url: string, config?: IHttpRequestConfig): Observable<IHttpResponse>;
    /**
     *
     *
     * @param {string} url
     * @param {IHttpRequestConfig} [config]
     * @returns {Observable<IHttpResponse>}
     * @memberof HTTPService
     */
    static head(url: string, config?: IHttpRequestConfig): Observable<IHttpResponse>;
    /**
     *
     *
     * @param {string} url
     * @param {*} [data]
     * @param {IHttpRequestConfig} [config]
     * @returns {Observable<IHttpResponse>}
     * @memberof HTTPService
     */
    static post(url: string, data?: any, config?: IHttpRequestConfig): Observable<IHttpResponse>;
    /**
     *
     *
     * @param {string} url
     * @param {*} [data]
     * @param {IHttpRequestConfig} [config]
     * @returns {Observable<IHttpResponse>}
     * @memberof HTTPService
     */
    static put(url: string, data?: any, config?: IHttpRequestConfig): Observable<IHttpResponse>;
    /**
     *
     *
     * @param {string} url
     * @param {*} [data]
     * @param {IHttpRequestConfig} [config]
     * @returns {Observable<IHttpResponse>}
     * @memberof HTTPService
     */
    static patch(url: string, data?: any, config?: IHttpRequestConfig): Observable<IHttpResponse>;
    /**
     *
     *
     * @param {IHttpRequestConfig} config
     * @returns {Observable<IHttpResponse>}
     * @memberof HTTPService
     */
    static request(config: IHttpRequestConfig): Observable<IHttpResponse>;
}
