export interface ITelemetry {
    'pdata': IProducerData;
    'env': string;
    'apislug': string;
    'channel': string;
    'uid': string;
    'endpoint': string;
    'did'?: string;
    'authtoken'?: string;
    'sid'?: string;
    'batchsize'?: Number;
    'runningEnv'?: string;
    'mode'?: string;
    'host'?: string;
    'tags'?: Array<string>;
    'cdata'?: Array<{}>;
    'dispatcher'?: "http" | "console";
}
export interface IProducerData {
    'id': string;
    'ver': string;
    'pid': string;
}
export interface IDeviceSpec {
    "os"?: string;
    "make"?: string;
    "id"?: string;
    "mem"?: number;
    "idisk"?: number;
    "edisk"?: number;
    "scrn"?: number;
    "camera"?: string;
    "cpu"?: string;
    "sims"?: number;
    "cap"?: Array<any>;
}
export interface IStartEventData {
    'type': string;
    'pageid'?: string;
    'mode'?: string;
    'dspec'?: IDeviceSpec;
    'uaspec'?: Object;
    'loc'?: string;
    'duration'?: Number;
}
export interface IErrorEventData {
    'err': string;
    'errtype': string;
    'stacktrace': string;
}
export interface IEndEventData {
    'pageid'?: string;
    'duration'?: string;
    'type': string;
    'mode'?: string;
    'summary'?: Array<{
        [index: string]: string;
    }>;
}
export interface ILogEventData {
    'type': string;
    'level': string;
    'message': string;
    'pageid'?: string;
    'params'?: Array<{}>;
}
export interface ITelemetryEvent {
    'edata': IStartEventData | IErrorEventData | IEndEventData | ILogEventData | IShareEventData | IAuditEventData | ISearchEventData;
    'contentId'?: string;
    'contentVer'?: string;
    'options': TelemetryEventOptions;
}
export interface IAuditEventData {
    "props": Array<string>;
    "state"?: string;
    "prevstate"?: string;
}
export interface ITelemetryContextData {
    'channel': string;
    'uid': string;
    'env': string;
    'pdata'?: {};
    'sid'?: string;
    'did'?: string;
    'cdata'?: Array<{}>;
    'rollup'?: {};
}
export interface TelemetryObject {
    'id': string;
    'type': string;
    'ver'?: string;
    'rollup': {};
}
export interface TelemetryEventOptions {
    'context'?: ITelemetryContextData;
    'object'?: TelemetryObject;
    'actor'?: {
        'id': string;
        'type': string;
    };
    'tags'?: Array<string>;
}
export interface IShareEventData {
    'type': string;
    'dir': string;
    'items': Array<{}>;
}
export interface ISearchEventData {
    "type": string;
    "query": string;
    "filters"?: {};
    "sort"?: {};
    "correlationid"?: string;
    "size": number;
    "topn": Array<{}>;
}
export interface IEventData {
    'context': {
        'env': string;
        'cdata'?: Array<{}>;
    };
    'actor'?: {
        'id': string;
        'type': string;
    };
    'object'?: {
        'id': string;
        'type': string;
        'ver'?: string;
        'rollup'?: {};
    };
    'tags'?: Array<string>;
    'edata': IEndEventData | IErrorEventData | ILogEventData | IShareEventData | IStartEventData | IAuditEventData | ISearchEventData;
}
