/*
*
* @author Sunil A S<sunils@ilimi.in>
*
*/
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const _ = require("lodash");
const http_service_1 = require("../http-service");
const typescript_ioc_1 = require("typescript-ioc");
/**
 * Telemetry Service to log telemetry v3 events
 *
 * @class TelemetryService
 */
let TelemetryService = class TelemetryService {
    /**
     *
     *
     * @param {ITelemetry} config
     * @param {*} provider
     * @memberof TelemetryService
     */
    initialize(config, provider) {
        this.provider = provider;
        this.config = _.cloneDeep(config);
        config.dispatcher = config.dispatcher ? this.getDispatcher(config.dispatcher) : this.getDispatcher('console');
        provider.initialize(config);
        console.log('Telemetry Service is initialized!');
    }
    /**
     *
     *
     * @param {IEventData} data
     * @memberof TelemetryService
     */
    log(data) {
        const eventData = this.getEventData(data);
        this.provider.log(eventData.edata, eventData.options);
    }
    /**
     *
     *
     * @param {IEventData} data
     * @memberof TelemetryService
     */
    audit(data) {
        const eventData = this.getEventData(data);
        this.provider.audit(eventData.edata, eventData.options);
    }
    /**
     *
     *
     * @param {IEventData} data
     * @memberof TelemetryService
     */
    error(data) {
        const eventData = this.getEventData(data);
        this.provider.error(eventData.edata, eventData.options);
    }
    /**
     *
     *
     * @param {IEventData} data
     * @memberof TelemetryService
     */
    search(data) {
        const eventData = this.getEventData(data);
        this.provider.search(eventData.edata, eventData.options);
    }
    /**
     *
     *
     * @param {IEventData} data
     * @memberof TelemetryService
     */
    start(data) {
        const eventData = this.getEventData(data);
        this.provider.start(this.config, eventData.options.object.id, eventData.options.object.ver, eventData.edata, eventData.options);
    }
    /**
     *
     *
     * @param {IEventData} data
     * @memberof TelemetryService
     */
    end(data) {
        const eventData = this.getEventData(data);
        this.provider.end(eventData.edata, eventData.options);
    }
    getRollUpData(data = []) {
        const rollUp = {};
        data.forEach((element, index) => rollUp['l' + index] = element);
        return rollUp;
    }
    getEventData(event) {
        return {
            edata: event.edata,
            options: {
                context: this.getEventContext(event),
                object: this.getEventObject(event),
                actor: event.actor,
                tags: event.tags || []
            }
        };
    }
    getEventObject(event) {
        if (_.get(event, 'object.id')) {
            return {
                id: _.get(event, 'object.id') || '',
                type: _.get(event, 'object.type') || '',
                ver: _.get(event, 'object.ver') || '',
                rollup: _.get(event, 'object.rollup') || {}
            };
        }
    }
    getEventContext(event) {
        return {
            channel: _.get(event, 'context.channel') || this.config.channel,
            pdata: _.get(event, 'context.pdata') || this.config.pdata,
            env: _.get(event, 'env') || this.config.env,
            sid: _.get(event, 'sid') || this.config.sid,
            uid: this.config.uid,
            cdata: _.get(event, 'context.cdata') || [],
            // TODO: get rollup data from event
            rollup: this.getRollUpData()
        };
    }
    getDispatcher(type) {
        let dispatchers = {
            'console': {
                dispatch: event => {
                    console.log('------TELEMETRY--LOG---------');
                    console.log('EVENT: ', JSON.stringify(event));
                }
            },
            'http': {
                dispatch: event => {
                    // TODO: config object for http service
                    http_service_1.HTTPService.post(this.config.host + this.config.endpoint, JSON.stringify(event)).subscribe((result) => {
                        // console.log(result)
                    });
                }
            }
        };
        return dispatchers[type];
    }
};
TelemetryService = __decorate([
    typescript_ioc_1.Singleton
], TelemetryService);
exports.TelemetryService = TelemetryService;
//# sourceMappingURL=TelemetryService.js.map