import { ITelemetry, IEventData } from './interfaces/TelemetryService';
/**
 * Telemetry Service to log telemetry v3 events
 *
 * @class TelemetryService
 */
export declare class TelemetryService {
    private provider;
    private config;
    /**
     *
     *
     * @param {ITelemetry} config
     * @param {*} provider
     * @memberof TelemetryService
     */
    initialize(config: ITelemetry, provider: any): void;
    /**
     *
     *
     * @param {IEventData} data
     * @memberof TelemetryService
     */
    log(data: IEventData): void;
    /**
     *
     *
     * @param {IEventData} data
     * @memberof TelemetryService
     */
    audit(data: IEventData): void;
    /**
     *
     *
     * @param {IEventData} data
     * @memberof TelemetryService
     */
    error(data: IEventData): void;
    /**
     *
     *
     * @param {IEventData} data
     * @memberof TelemetryService
     */
    search(data: IEventData): void;
    /**
     *
     *
     * @param {IEventData} data
     * @memberof TelemetryService
     */
    start(data: IEventData): void;
    /**
     *
     *
     * @param {IEventData} data
     * @memberof TelemetryService
     */
    end(data: IEventData): void;
    private getRollUpData;
    private getEventData;
    private getEventObject;
    private getEventContext;
    private getDispatcher;
}
