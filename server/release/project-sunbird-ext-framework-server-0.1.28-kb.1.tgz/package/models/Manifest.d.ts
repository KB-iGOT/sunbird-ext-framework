/**
 * @author Santhosh Vasabhaktula <santhosh@ilimi.in>
 */
import { IPlugin } from "../interfaces";
/**
 *
 *
 * @export
 * @interface IRouteSchema
 */
export interface IRouteSchema {
    prefix: string;
}
/**
 *
 *
 * @export
 * @interface IDatabaseType
 */
export interface IDatabaseType {
    type: string;
    path: string;
    compatibility: string;
}
/**
 *
 *
 * @export
 * @interface IServerSchema
 */
export interface IServerSchema {
    routes?: IRouteSchema;
    dependencies?: Array<IPlugin>;
    databases?: Array<IDatabaseType>;
}
/**
 *
 *
 * @export
 * @interface IPluginManifest
 */
export interface IPluginManifest {
    id: string;
    name: string;
    version: string;
    author: string;
    description?: string;
    server: IServerSchema;
}
/**
 *
 *
 * @export
 * @class Manifest
 */
export declare class Manifest {
    private _id;
    private _name;
    private _version;
    private _author;
    private _description;
    private _server;
    private json;
    /**
     * Creates an instance of Manifest.
     * @param {IPluginManifest} manifest
     * @memberof Manifest
     */
    constructor(manifest: IPluginManifest);
    /**
     *
     *
     * @static
     * @param {(IPluginManifest | string)} json
     * @returns {Manifest}
     * @memberof Manifest
     */
    static fromJSON(json: IPluginManifest | string): Manifest;
    /**
     *
     *
     * @readonly
     * @type {string}
     * @memberof Manifest
     */
    readonly id: string;
    /**
     *
     *
     * @readonly
     * @type {string}
     * @memberof Manifest
     */
    readonly name: string;
    /**
     *
     *
     * @readonly
     * @type {string}
     * @memberof Manifest
     */
    readonly version: string;
    /**
     *
     *
     * @readonly
     * @type {string}
     * @memberof Manifest
     */
    readonly author: string;
    /**
     *
     *
     * @readonly
     * @type {string}
     * @memberof Manifest
     */
    readonly description: string;
    /**
     *
     *
     * @readonly
     * @type {IServerSchema}
     * @memberof Manifest
     */
    readonly server: IServerSchema;
    /**
     *
     *
     * @returns
     * @memberof Manifest
     */
    getDependencies(): IPlugin[];
    /**
     *
     *
     * @param {boolean} toString
     * @returns {(IPluginManifest | string)}
     * @memberof Manifest
     */
    toJSON(toString?: boolean): IPluginManifest | string;
}
