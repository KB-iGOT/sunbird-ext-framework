import { Manifest } from "./Manifest";
/**
 * @author Sunil A S <sunils@ilimi.in>
 */
/**
 *
 *
 * @export
 * @interface IPluginLifeCycleEvents
 */
export interface IPluginLifeCycleEvents {
    onLoad?(): any;
    onUnload?(): any;
    onStart?(): any;
    onStop?(): any;
}
export declare class BaseServer {
    protected cassandra: any;
    protected elasticsearch: any;
    protected manifest: Manifest;
    protected constructor(manifest: Manifest);
}
