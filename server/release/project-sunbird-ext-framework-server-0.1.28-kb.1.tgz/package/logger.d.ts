import { Logger } from 'log4js';
import { FrameworkConfig } from './api';
declare const logger: Logger;
declare type loggerLevels = 'all' | 'trace' | 'fatal' | 'error' | 'off' | 'info' | 'warn' | 'debug';
declare function enableLogger(config: FrameworkConfig): void;
export { logger, enableLogger, loggerLevels };
